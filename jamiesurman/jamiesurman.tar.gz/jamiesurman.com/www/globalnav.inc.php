<div id="global_nav" class="portfolio">
  <ul>
	  <li id="gn_jamie_surman">Jamie Surman</li>
  	<li id="gn_portfolio"><a href="?page=portfolio">Portfolio</a></li>
    <li id="gn_contact"><a href="?page=contact">Contact</a></li>
  </ul>
  <a href="?page=portfolio" id="thumbnails_button">Show Thumbnails</a>
  <a href="" id="left_arrow_button">Previous Image</a>
  <a href="" id="right_arrow_button">Next Image</a>
  
  <div id="contact_div">
  	T: +44 (0)7974 924560<br />
		E: info@jamiesurman.com<br /><br />
    site by <a href="http://bespoke.dimy.co.uk" target="_blank">dimy.co.uk</a>
  </div>
</div>