<?php

session_name('jamiesurman');
session_start();

header("Content-type: text/css");


?>

* html img, * html div {
	behavior: url(iepngfix.htc);
}

html {
	height: 100%;
}

body {
	margin: 0;
  height: 100%;
	color: #7a7a7a;
	font: 10px/12px Arial, Verdana, sans-serif;
	background-color: #F5F5F5;
  letter-spacing: 0.05em;
}

.cleardiv {
	clear: both;
	margin: -1px;
	height: 1px;
	overflow: hidden;
	font-size: 0;
	line-height: 0;
} 

p {
	margin-bottom: 20px;
}

p:last-child {
  margin-bottom: 0px;
}

a {
	color: #7a7a7a;
	text-decoration: none;
}

a:hover {
	color: #555555;
	text-decoration: none;
}

a:active, a:focus, button:active, button:focus {
	outline: none;
	-moz-outline-style: none;
}

h1, h2, h3, h4, h5, h6 {
	color: #dae2ed;
}

h1 {
	font-size: 3em;
	font-weight: normal;
	line-height: 1.4;
	margin-bottom: 0.3em;
}

h2 {
	font-size: 2em;
	font-weight: normal;
	line-height: 0.8;
	margin-bottom: 0.8em;
  padding-top: 30px;
}

h3 {
	font-size:1.3em;
	font-weight: normal;
	line-height: 1.4;
	margin-bottom: 0.3em;
}

h4 {
	font-size: 1em;
	line-height: 1.5;
}

h5 {
}

h6 {
}

hr {
	border: 0;
	margin: 0px 0px 20px 0px;
	color: #d5d5d6;
	background-color: #d5d5d6;
	height: 1px;
	width: 100%;
	text-align: left;
}

button:hover {
	cursor: pointer;
}

button::-moz-focus-inner,
input[type="reset"]::-moz-focus-inner,
input[type="button"]::-moz-focus-inner,
input[type="submit"]::-moz-focus-inner,
input[type="file"] > input[type="button"]::-moz-focus-inner {
    border: none;
}

img.ajaxloadergif {
	margin: auto auto;
  display: block;
  width: 131px;
  height: 7px;
  position: absolute;
  top: 50%;
  left: 50%;
  margin-left: -65px;
  margin-top: -7px;
}

#white_section {
  height: 592px;
  /* margin-top: 118px; */
  background-color: #FFFFFF;
}

#main_image_section {
	position: relative;
	width: 911px;
  margin: auto auto;
  height: 592px;
  background-color: #FFFFFF;
  text-align: center;
}

#global_nav {
	margin: 29px auto;
  position: relative;
	width: 911px;
}

#global_nav.portfolio ul li#gn_portfolio a, #global_nav.contact ul li#gn_contact a, #global_nav ul li#gn_jamie_surman {
	color: #555555;
}

#global_nav ul li#gn_jamie_surman {
	margin-bottom: 12px;
}

#global_nav a#thumbnails_button {
	position: absolute;
  top: 4px;
	right: 0;
	width: 43px;
	height: 0px;
  padding-top: 43px;
  overflow: hidden;
	background-image: url("images/thumbnailsbn.gif");
	display: block;
}

#global_nav a#thumbnails_button:hover {
	background-position: 0 -43px;
}

#global_nav a#thumbnails_button.active {
	background-position: 0 -43px;
}

#global_nav a#left_arrow_button {
	position: absolute;
  top: 4px;
	left: 426px;
	width: 27px;
	height: 0px;
  padding-top: 42px;
  overflow: hidden;
	background-image: url("images/arrowbuttons.gif");
	display: block;
}

#global_nav a#left_arrow_button:hover {
	background-position: 0 -42px;
}

#global_nav a#right_arrow_button {
	position: absolute;
  top: 4px;
	left: 465px;
	width: 27px;
	height: 0px;
  padding-top: 42px;
  overflow: hidden;
	background-image: url("images/arrowbuttons.gif");
  background-position: -39px 0;
	display: block;
}

#global_nav a#right_arrow_button:hover {
	background-position: -39px -42px;
}

#global_nav #contact_div {
	position: absolute;
  top: 0;
	right: 0;
	display: none;
  text-align: right;
}

#thumbnails_section, #reorder_thumbnails_section {
  margin: 0 auto;
  position: relative;
  width: 911px;
  overflow: hidden;
}

#thumbnails_section ul li {
	float: left;
  margin-right: 15px;
  margin-bottom: 15px;
  -moz-opacity: 0;
  filter:alpha(opacity=0);
  opacity: 0;
}

#thumbnails_section ul li a, #reorder_thumbnails_section ul li a {
	display: block;
  width: 164px;
  height: 107px;
  border: 3px solid #E8E8E8;
}

#thumbnails_section ul > :nth-child(5n+5) {
	margin-right: 0;
}

#thumbnails_section ul li.selected a {
  border-color: #CCCCCC;
}

#reorder_thumbnails_section {
  margin: 0 auto;
  position: relative;
  width: 950px;
  overflow: hidden;
}

#reorder_thumbnails_section ul li {
	float: left;
  margin-right: 15px;
  margin-bottom: 15px;
}

#reorder_thumbnails_section ul li.ui-state-highlight {
	background-color: #f5f5f5;
  background-image: none;
}

#reorder_thumbnails_section ul li.ui-sortable-helper {
	background-color: #E15151;
}


/* Standard form css */

.standardform input, .standardform textarea {
	color: #8a8989;
	-moz-border-radius: 4px;
	-webkit-border-radius: 4px;
	background-color: #dce8ef;
	border: 1px solid #cecece;
	padding: 5px;
}

.standardform input:hover, .standardform textarea:hover {
	border: 1px solid #b7b7b7;
	background-color: #e3eff7;
}

.standardform input:focus, .standardform textarea:focus {
	border: 1px solid #b7b7b7;
	background-color: #edf3f7;
}

.standardform label {
	display: block;
	margin-bottom: 5px;
}

.standardform button {
	margin: 0;
	padding: 0;
	background-color:transparent;
	border:0 none;
	display: block;
	height: 32px;
	outline-style: none;
	outline-width: medium;
	position: relative;
	text-indent: -9999em;
}

.standardform button:hover {
	background-position: 0 -32px;
}

.standardform#addslide textarea {
	resize: none;
	height: 80px;
	width: 273px;
}

.standardform#addslide button {
	background-image:url(images/sendbutton.png);
	width: 92px;
  float: left;
}

.standardform#addslide {
	margin-bottom: 10px;
}

div.formerrorbox {
	color: #000000;
  padding: 5px;
  background-color: #f5f5f5;
  border: 1px solid red;
  margin-bottom: 10px;
  margin-top: 10px;
}

.standardform label.error {
	color: #ff0000;
}

/* end of standard form css */


